
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class servletstu extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public servletstu() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String id = request.getParameter("stuId");
		String name = request.getParameter("stuname");
		int age = Integer.parseInt(request.getParameter("stuage"));
		int marks = Integer.parseInt(request.getParameter("stumarks"));
		float percent = Float.parseFloat(request.getParameter("stupercent"));
		String grade = request.getParameter("stugrade");
		String filename="C:\\Users\\AMU\\Documents\\fileswriterjava\\mydata.txt";
		response.setContentType("text/html;charset=UTF-8");
		try (PrintWriter out = response.getWriter()) {

			out.println("student id is :" + id);
			out.println("<br>");
			out.println("student name is :" + name);
			out.println("<br>");
			out.println("student age is :" + age);
			out.println("<br>");
			out.println("student marks is :" + marks);
			out.println("<br>");
			out.println("student percentage is :" + percent);
			out.println("<br>");
			out.println("student grade is :" + grade);
			out.println("<br>");
			int count = 0;
			char ch[] = id.toCharArray();
			if (ch[0] == 'S' || ch[0] == 's') {
				for (int i = 1; i < 4; i++) {
					if (Character.isDigit(ch[i])) {
						count++;
					} else {
						out.println("invalid id");
						out.println("<br>");
						break;
					}
				}
				if (count == 3) {
					out.println("valid id");
					out.println("<br>");
				}
			} else {
				out.println("invalid id");
				out.println("<br>");
			}
			if (grade.charAt(0) == ('a') || grade.charAt(0) == ('b') || grade.charAt(0) == ('c')
					|| grade.charAt(0) == ('d') || grade.charAt(0) == ('e')) {
				out.println("valid grade");
			} else {
				out.println("invalid grade");
			}
		}
		int position=0;
		ArrayList al = new ArrayList();
		al.add("id is :"+id);
		al.add(name);
		al.add(age);
		al.add(marks);
		al.add(percent);
		al.add(grade);
		
		try {
			File fin = new File(filename);
			FileWriter fos=new FileWriter(fin,true);
			BufferedWriter br=new BufferedWriter(fos);
			br.write(id);
			br.write(name);
			br.write(age);
			br.write(marks);
			br.write((int)percent);
			br.write(grade);
			br.newLine();
			br.close();
			} finally {
		}
		String read;
		int count=0,count1=0,count2=0;
		try{
			File fin = new File(filename);
			FileReader fos=new FileReader(fin);
			BufferedReader br=new BufferedReader(fos);
			PrintWriter out = response.getWriter();
			System.out.println("line 112 executed");
			while((read=br.readLine())!=null){
			read.split("\n");
				if(read.equals('b')||read.equals('a')){
					count++;
				}
				if(read.equals('c')||read.equals('d')||read.equals('e')){
					count1++;
				}
			}
			System.out.println("line 122 executed");
			out.println("the no of passed :"+count1);
			out.println("the no of fail :"+count);
		}
		finally{
			
		}
	}
	
}
